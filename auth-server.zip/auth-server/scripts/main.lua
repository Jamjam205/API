-- Your Roblox script goes here
print('Authorized and running!')